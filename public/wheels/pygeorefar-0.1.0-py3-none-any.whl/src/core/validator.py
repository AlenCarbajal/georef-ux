from pydantic import ValidationError

def validate_params(params_class, raw_params: dict):
    try:
        return params_class(**raw_params)
    except ValidationError as e:
        raise ValueError(f"Parámetros inválidos:\n{e}")
