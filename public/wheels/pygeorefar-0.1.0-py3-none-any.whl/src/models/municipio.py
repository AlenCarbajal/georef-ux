from pydantic import Field
from typing import Optional

from .unidad_territorial import UnidadTerritorial
from .provincia import Provincia

class Municipio(UnidadTerritorial):
    """
    Modelo de datos para un municipio.
    """
    provincia: Optional[Provincia] = Field(None, description="Provincia a la que pertenece el municipio")
    
    class Params(UnidadTerritorial.Params):
        """Parámetros de consulta para buscar municipios."""
        provincia: Optional[str] = Field(None, description="ID de la provincia a la que pertenece el municipio")