from pydantic import BaseModel, Field
from typing import Optional
from .provincia import Provincia
from .departamento import Departamento
from .punto import Punto
from .params import BaseParams

class InstitucionUniversitaria(BaseModel):
    """
    Modelo de datos para una institución universitaria.
    """
    id: str = Field(..., description="ID único de la institución")
    nombre: str = Field(..., description="Nombre de la unidad académica")
    domicilio: Optional[str] = Field(None, description="Domicilio de la institución")
    provincia: Optional[Provincia] = Field(None, description="Provincia donde se ubica")
    departamento: Optional[Departamento] = Field(None, description="Departamento donde se ubica")
    universidad: Optional[str] = Field(None, description="Nombre de la universidad")
    unidad_academica: Optional[str] = Field(None, description="Nombre de la unidad académica")
    gestion: Optional[str] = Field(None, description="Tipo de gestión (Estatal/Privada)")
    centroide: Optional[Punto] = Field(None, description="Coordenadas geográficas")
    
    class Params(BaseParams):
        """Parámetros de consulta para buscar instituciones universitarias."""
        provincia: Optional[str] = Field(None, description="Filtrar por provincia")
        departamento: Optional[str] = Field(None, description="Filtrar por departamento")
        universidad: Optional[str] = Field(None, description="Filtrar por universidad")
        gestion: Optional[str] = Field(None, description="Filtrar por tipo de gestión")
