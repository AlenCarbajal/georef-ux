from pydantic import BaseModel, ConfigDict, Field
from typing import Optional

from .params import BaseParams
from .departamento import Departamento
from .provincia import Provincia
from .municipio import Municipio


class Ubicacion(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra="allow")

    departamento: Optional[Departamento] = Field(None)
    provincia: Optional[Provincia] = Field(None)
    municipio: Optional[Municipio] = Field(None)
    lat: Optional[float] = Field(None, description="Latitud del punto")
    lon: Optional[float] = Field(None, description="Longitud del punto")

    class Params(BaseParams):
        lat: Optional[float] = Field(None, description="Latitud del punto de interés")
        lon: Optional[float] = Field(None, description="Longitud del punto de interés")
