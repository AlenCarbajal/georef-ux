from .unidad_territorial import UnidadTerritorial
from .provincia import Provincia
from .departamento import Departamento
from pydantic import Field
from typing import Optional

class FraccionCensal(UnidadTerritorial):
    """
    Modelo de datos para una fracción censal.
    """
    nombre: Optional[str] = Field(None, description="Nombre de la fracción censal")
    provincia: Optional[Provincia] = Field(None, description="Provincia a la que pertenece")
    departamento: Optional[Departamento] = Field(None, description="Departamento a la que pertenece")
    
    class Params(UnidadTerritorial.Params):
        """Parámetros de consulta para buscar fracciones censales."""
        provincia: Optional[str] = Field(None, description="Nombre o ID de la provincia")
        departamento: Optional[str] = Field(None, description="Nombre o ID del departamento")
