from pydantic import ConfigDict, Field
from typing import Optional

from .unidad_territorial import UnidadTerritorial
from .provincia import Provincia

class Departamento(UnidadTerritorial):
    """
    Modelo de datos para un departamento.
    """
    provincia: Optional[Provincia] = Field(None, description="Provincia a la que pertenece el departamento")

    def __str__(self):
        return super().__str__()
    
    class Params(UnidadTerritorial.Params):
        """Parámetros de consulta para buscar municipios."""
        provincia: Optional[str] = Field(None, description="ID de la provincia a la que pertenece el municipio")
