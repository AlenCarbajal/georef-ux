from pydantic import BaseModel, ConfigDict, Field, field_validator
from typing import Literal, Optional

from .custom_types import Campos, Orden

class BaseParams(BaseModel):
        model_config = ConfigDict(arbitrary_types_allowed = True)

        # Parámetros para búsqueda
        id: Optional[str] = Field(None, description="ID único de la entidad")
        nombre: Optional[str] = Field(None, description="Nombre de la entidad")
        aplanar: Optional[bool] = Field(None, description="Aplanar la respuesta")
        max: Optional[int] = Field(None, description="Máximo número de resultados a devolver")
        inicio: Optional[int] = Field(None, description="Número de inicio para paginación")
        exacto: Optional[bool] = Field(None, description="Buscar coincidencias exactas")

        campos: Optional[str] = Field(None, description="Campos a incluir en la respuesta")
        orden: Optional[Literal["id", "nombre"]] =  Field(None, description="Orden de los resultados")
        formato: Optional[Literal["json","geojson","csv","xml"]] = Field(None, description="Formato de la respuesta")

        def dump_params(self):
            data = self.model_dump(exclude_none=True)
            for k, v in data.items():
                if isinstance(v, int):
                    data[k] = str(v)
            return data


        @field_validator('campos')
        @classmethod
        def validate_campos(cls, value):
            if isinstance(value, Campos) or not value:
                return value
            if isinstance(value, list):
                value = ','.join(value)
            elif not isinstance(value, str):
                raise ValueError("campos debe ser una cadena de texto, lista o elemento de Campos")

            valid_fields = set()

            for base in cls.__mro__:
                if hasattr(base, 'model_fields'):
                    valid_fields.update(base.model_fields.keys())

            valid_fields.update(Campos.values())

            fields = [f.strip() for f in value.split(',')]
            invalid = [f for f in fields if f not in valid_fields]

            if invalid:
                raise ValueError(f"Campos inválidos: {', '.join(invalid)}")
            return fields