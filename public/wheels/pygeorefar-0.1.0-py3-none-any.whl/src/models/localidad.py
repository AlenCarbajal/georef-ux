from .provincia import Provincia
from .departamento import Departamento
from .localidad_censal import LocalidadCensal
from .unidad_territorial import UnidadTerritorial
from .municipio import Municipio

from typing import Optional

from pydantic import Field

class Localidad(UnidadTerritorial):
    provincia: Optional[Provincia] = Field(None, description="Provincia a la que pertenece la localidad")
    municipio: Optional[Municipio] = Field(None, description="Municipio al que pertenece la localidad")
    departamento: Optional[Departamento] = Field(None, description="Departamento al que pertenece la localidad")
    localidad_censal: Optional[LocalidadCensal] = Field(None, description="Localidad censal a la que pertenece la localidad")

    class Params(UnidadTerritorial.Params):
        provincia: Optional[str] = Field(None, description="Código, nombre u objeto de la provincia a la que pertenece la localidad")
        municipio: Optional[str] = Field(None, description="Código, nombre u objeto del municipio al que pertenece la localidad")
        departamento: Optional[str] = Field(None, description="Código, nombre u objeto del departamento al que pertenece la localidad")
        localidad_censal: Optional[str] = Field(None, description="Código, nombre u objeto de la localidad censal a la que pertenece la localidad")
