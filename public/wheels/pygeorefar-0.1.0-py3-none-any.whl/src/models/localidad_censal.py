from pydantic import Field

from typing import Optional
from .provincia import Provincia
from .municipio import Municipio
from .departamento import Departamento
from .unidad_territorial import UnidadTerritorial

class LocalidadCensal(UnidadTerritorial):
    """Modelo de datos para una localidad censal."""
    provincia: Optional[Provincia] = Field(None, description="Provincia a la que pertenece la localidad censal")
    municipio: Optional[Municipio] = Field(None, description="Municipio al que pertenece la localidad censal")
    departamento: Optional[Departamento] = Field(None, description="Departamento al que pertenece la localidad censal")

    class Params(UnidadTerritorial.Params):
        """Parámetros de consulta para buscar localidades censales."""
        provincia: Optional[str] = Field(None, description="Nombre, ID u objeto de la provincia a la que pertenece la localidad censal")
        municipio: Optional[str] = Field(None, description="Nombre, ID u objeto del municipio al que pertenece la localidad censal")
        departamento: Optional[str] = Field(None, description="Nombre, ID u objeto del departamento al que pertenece la localidad censal")