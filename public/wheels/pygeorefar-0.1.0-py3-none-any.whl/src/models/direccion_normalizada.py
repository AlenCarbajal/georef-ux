from pydantic import BaseModel, Field
from typing import Optional

from .params import BaseParams

class Altura(BaseModel):
    """Altura de una dirección."""
    valor: Optional[int] = Field(None, description="Número de altura")
    unidad: Optional[str] = Field(None, description="Unidad (ej: Nro.)")

class DireccionNormalizada(BaseModel):
    """Modelo de datos para una dirección normalizada."""
    altura: Optional[Altura] = Field(None, description="Altura de la dirección")
    calle: Optional[dict] = Field(None, description="Calle de la dirección")
    calle_cruce_1: Optional[dict] = Field(None, description="Primera calle de cruce")
    calle_cruce_2: Optional[dict] = Field(None, description="Segunda calle de cruce")
    piso: Optional[str] = Field(None, description="Piso/apartamento")
    nomenclatura: Optional[str] = Field(None, description="Nomenclatura completa")
    ubicacion: Optional[dict] = Field(None, description="Ubicación geográfica")
    provincia: Optional[dict] = Field(None, description="Provincia")
    departamento: Optional[dict] = Field(None, description="Departamento")
    localidad_censal: Optional[dict] = Field(None, description="Localidad censal")
    categoria: Optional[str] = Field(None, description="Categoría de la dirección")

    class Params(BaseParams):
        """Parámetros para buscar direcciones."""
        direccion: str = Field(..., description="Dirección a normalizar")
        provincia: Optional[str] = Field(None, description="Provincia (filtro)")
        departamento: Optional[str] = Field(None, description="Departamento (filtro)")
        localidad_censal: Optional[str] = Field(None, description="Localidad censal (filtro)")
        localidad: Optional[str] = Field(None, description="Localidad (filtro)")
        desplazar: Optional[bool] = Field(None, description="Desplazar punto a manzana")