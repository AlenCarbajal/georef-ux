from pydantic import BaseModel, Field
from typing import Optional
from .provincia import Provincia
from .departamento import Departamento
from .punto import Punto
from .params import BaseParams

class EstablecimientoEducativo(BaseModel):
    """
    Modelo de datos para un establecimiento educativo.
    """
    id: str = Field(..., description="ID único del establecimiento")
    nombre: str = Field(..., description="Nombre del establecimiento")
    domicilio: Optional[str] = Field(None, description="Domicilio del establecimiento")
    provincia: Optional[Provincia] = Field(None, description="Provincia donde se ubica")
    departamento: Optional[Departamento] = Field(None, description="Departamento donde se ubica")
    categoria: Optional[str] = Field(None, description="Categoría del establecimiento (ESCUELA, etc)")
    gestion: Optional[str] = Field(None, description="Tipo de gestión (Estatal/Privada)")
    centroide: Optional[Punto] = Field(None, description="Coordenadas geográficas")
    
    class Params(BaseParams):
        """Parámetros de consulta para buscar establecimientos educativos."""
        provincia: Optional[str] = Field(None, description="Filtrar por provincia")
        departamento: Optional[str] = Field(None, description="Filtrar por departamento")
        gestion: Optional[str] = Field(None, description="Filtrar por tipo de gestión")
