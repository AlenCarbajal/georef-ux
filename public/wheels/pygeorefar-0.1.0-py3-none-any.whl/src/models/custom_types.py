from enum import Enum

class Campos(Enum):
    BASICO = "basico"
    ESTANDAR = "estandar"
    COMPLETO = "completo"
    
    @classmethod
    def values(cls):
        """Devuelve todos los valores del enum"""
        return [item.value for item in cls]
    
    def __str__(self):
        """Devuelve el nombre del campo en minúsculas"""
        return self.value
    
    def __repr__(self):
        """Devuelve el nombre del campo en minúsculas"""
        return  self.value

class Orden:
    ID = "id"
    NOMBRE = "nombre"