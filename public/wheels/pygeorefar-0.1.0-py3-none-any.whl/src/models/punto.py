from pydantic import BaseModel

class Punto(BaseModel):
    lat: float
    lon: float

    def __str__(self):
        return str(self.__dict__)
    
    def __repr__(self):
        return self.__str__()

    def tuple(self) -> tuple[float, float]:
        """
        Convierte el punto a una tupla (latitud, longitud).
        :return: Tupla con latitud y longitud.
        """
        return (self.lat, self.lon)