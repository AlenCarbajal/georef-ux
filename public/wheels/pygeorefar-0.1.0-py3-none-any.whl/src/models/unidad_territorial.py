from pydantic import BaseModel, ConfigDict, Field
from typing import Optional

from .punto import Punto
from .params import BaseParams

class UnidadTerritorial(BaseModel):
    """
    Modelo de datos para una unidad territorial.
    """
    model_config = ConfigDict(arbitrary_types_allowed = True, extra="allow")

    id:  str = Field(..., description="ID único de la unidad territorial")
    nombre: str = Field(..., description="Nombre de la unidad territorial")

    # Campos opcionales
    fuente: Optional[str] = None
    categoria: Optional[str] = None
    centroide: Optional[Punto] = None
    nombre_completo: Optional[str] = None

    def get_entity_id(self) -> str:
        """
        Devuelve el ID de la entidad.
        """
        return self.id

    class Params(BaseParams):
        model_config = ConfigDict(arbitrary_types_allowed = True)

        interseccion: Optional[str] = Field(None, description="Intersección con otra unidad territorial")

    def __str__(self):
        return str({key: value for key, value in self.__dict__.items() if value is not None})

    def __repr__(self):
        return self.__str__()


