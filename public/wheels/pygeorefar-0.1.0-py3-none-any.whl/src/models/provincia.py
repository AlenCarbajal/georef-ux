from .unidad_territorial import UnidadTerritorial

from pydantic import ConfigDict, Field
from typing import Optional

class Provincia(UnidadTerritorial):
    """
    Modelo de datos para una provincia.
    """
    iso_id: Optional[str] = Field(None, description="ID ISO de la provincia")
    iso_nombre: Optional[str] = Field(None, description="Nombre ISO de la provincia")

    class Params(UnidadTerritorial.Params):
        """Parámetros de consulta para buscar provincias."""
        pass