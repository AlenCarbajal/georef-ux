from .unidad_territorial import UnidadTerritorial
from .provincia import Provincia
from pydantic import Field
from typing import Optional

class GobiernoLocal(UnidadTerritorial):
    """
    Modelo de datos para un gobierno local (municipio, comisión, etc).
    """
    provincia: Optional[Provincia] = Field(None, description="Provincia a la que pertenece el gobierno local")
    categoria: Optional[str] = Field(None, description="Categoría del gobierno local")
    
    class Params(UnidadTerritorial.Params):
        """Parámetros de consulta para buscar gobiernos locales."""
        provincia: Optional[str] = Field(None, description="Nombre o ID de la provincia")
        categoria: Optional[str] = Field(None, description="Categoría del gobierno local")
