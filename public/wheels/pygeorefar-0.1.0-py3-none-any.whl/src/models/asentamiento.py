from .unidad_territorial import UnidadTerritorial
from .provincia import Provincia
from .departamento import Departamento
from .localidad_censal import LocalidadCensal
from .municipio import Municipio

from pydantic import Field
from typing import Optional

class Asentamiento(UnidadTerritorial):
    """
    Modelo de datos para un asentamiento.
    """
    # Campos opcionales
    municipio: Optional[Municipio] = Field(None, description="Municipio al que pertenece al asentamiento")
    provincia: Optional[Provincia] = Field(None, description="Provincia a la que pertenece al asentamiento")
    departamento: Optional[Departamento] = Field(None, description="Departamento al que pertenece al asentamiento")
    localidad_censal: Optional[LocalidadCensal] = Field(None, description="Localidad censal a la que pertenece al asentamiento")
    
    class Params(UnidadTerritorial.Params):
        """Parámetros de consulta para buscar asentamientos."""
        municipio: Optional[str] = Field(None, description="Nombre del municipio al que pertenece el asentamiento")
        provincia: Optional[str] = Field(None, description="Nombre de la provincia a la que pertenece el asentamiento")
        departamento: Optional[str] = Field(None, description="Nombre del departamento al que pertenece el asentamiento")
        localidad_censal: Optional[str] = Field(None, description="Nombre de la localidad censal a la que pertenece el asentamiento")