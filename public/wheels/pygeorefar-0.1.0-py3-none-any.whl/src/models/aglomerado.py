from .unidad_territorial import UnidadTerritorial
from pydantic import Field
from typing import Optional

class Aglomerado(UnidadTerritorial):
    """
    Modelo de datos para un aglomerado (INDEC).
    """
    fuente: Optional[str] = Field(None, description="Fuente de datos (INDEC)")
    
    class Params(UnidadTerritorial.Params):
        """Parámetros de consulta para buscar aglomerados."""
        pass
