from .unidad_territorial import UnidadTerritorial
from .provincia import Provincia
from .departamento import Departamento
from .fraccion_censal import FraccionCensal
from pydantic import Field
from typing import Optional

class RadioCensal(UnidadTerritorial):
    """
    Modelo de datos para un radio censal.
    """
    nombre: Optional[str] = Field(None, description="Nombre del radio censal")
    provincia: Optional[Provincia] = Field(None, description="Provincia a la que pertenece")
    departamento: Optional[Departamento] = Field(None, description="Departamento a la que pertenece")
    fraccion_censal: Optional[FraccionCensal] = Field(None, description="Fracción censal a la que pertenece")
    categoria: Optional[str] = Field(None, description="Categoría del radio censal")
    
    class Params(UnidadTerritorial.Params):
        """Parámetros de consulta para buscar radios censales."""
        provincia: Optional[str] = Field(None, description="Nombre o ID de la provincia")
        departamento: Optional[str] = Field(None, description="Nombre o ID del departamento")
        fraccion_censal: Optional[str] = Field(None, description="Nombre o ID de la fracción censal")
