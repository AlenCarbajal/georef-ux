from pydantic import BaseModel, Field
from typing import Optional

from .provincia import Provincia
from .params import BaseParams
from .departamento import Departamento
from .localidad_censal import LocalidadCensal

class LimiteCalle(BaseModel):
    derecha: int = Field(None, description="Altura de fin de la calle a la derecha")
    izquierda: int = Field(None, description="Altura de fin de la calle a la izquierda")

class Altura(BaseModel):
    inicio: LimiteCalle = Field(None, description="Altura de inicio de la calle")
    fin: LimiteCalle = Field(None, description="Altura de fin de la calle")

class Calle(BaseModel):
    id: str = Field(None, description="ID de la calle")
    nombre: str = Field(None, description="Nombre de la calle")

    # Campos opcionales
    altura: Optional[Altura] = Field(None, description="Altura de la calle")
    categoria: Optional[str] = Field(None, description="Categoría de la calle")
    departamento: Optional[Departamento] = Field(None, description="Departamento al que pertenece la calle")
    localidad_censal: Optional[LocalidadCensal] = Field(None, description="Localidad censal a la que pertenece la calle")
    nomenclatura: Optional[str] = Field(None, description="Nomenclatura de la calle")
    provincia: Optional[Provincia] = Field(None, description="Provincia a la que pertenece la calle")
    fuente: Optional[str] = Field(None, description="Fuente de los datos de la calle")

    class Params(BaseParams):
        # Parámetros para la búsqueda de calles
        categoria: Optional[str] = Field(None, description="Categoría de la calle")
        departamento: Optional[str] = Field(None, description="Código, nombre u objeto del departamento al que pertenece la calle")
        localidad_censal: Optional[str] = Field(None, description="Código, nombre u objeto de la localidad censal a la que pertenece la calle")
        provincia: Optional[str] = Field(None, description="Código, nombre u objeto de la provincia a la que pertenece la calle")
