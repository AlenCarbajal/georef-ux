from typing import Optional
from pydantic import Field

from .unidad_territorial import UnidadTerritorial
from .ubicacion import Ubicacion

class GeorefInversa(UnidadTerritorial):
    latitud: float = Field(None, description="Latitud de la ubicación geográfica")
    longitud: float = Field(None, description="Longitud de la ubicación geográfica")

    # Campos opcionales
    ubicacion: Optional[Ubicacion] = None
    def __str__(self):
        return f"{self.nombre} ({self.id}) - Lat: {self.latitud}, Lon: {self.longitud}"