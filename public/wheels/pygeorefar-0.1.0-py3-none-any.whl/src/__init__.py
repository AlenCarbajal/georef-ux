"""pygeorefar - Cliente Python para API Georef Argentina V2"""

from .georef_client import GeorefClient

__version__ = "0.1.0"
__all__ = ["GeorefClient"]
