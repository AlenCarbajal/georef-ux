from src.core.validator import validate_params

def make_resource(model_class, endpoint_name: str, client):
    """
    Factory para crear funciones get y post para un recurso.
    
    Args:
        model_class: Clase del modelo (ej: Provincia.Provincia)
        endpoint_name: Nombre del endpoint (ej: 'provincias')
        client: Instancia de GeorefClient
    
    Returns:
        Tupla (get_fn, post_fn) con funciones para GET y POST
    """
    
    def get_fn(**kwargs):
        """GET con parámetros."""
        params = validate_params(model_class.Params, kwargs)
        return getattr(client, f'get_{endpoint_name}')(params)

    def post_fn(queries_list: list):
        """POST con lote de consultas."""
        validated = [
            validate_params(model_class.Params, q) 
            for q in queries_list
        ]
        return getattr(client, f'post_{endpoint_name}')(validated)

    return get_fn, post_fn