import requests
from src.models.provincia import Provincia
from src.models.departamento import Departamento
from src.models.municipio import Municipio
from src.models.localidad import Localidad
from src.models.localidad_censal import LocalidadCensal
from src.models.calle import Calle
from src.models.asentamiento import Asentamiento
from src.models.ubicacion import Ubicacion
from src.models.gobierno_local import GobiernoLocal
from src.models.aglomerado import Aglomerado
from src.models.fraccion_censal import FraccionCensal
from src.models.radio_censal import RadioCensal
from src.models.direccion_normalizada import DireccionNormalizada
from src.models.establecimiento_educativo import EstablecimientoEducativo
from src.models.institucion_universitaria import InstitucionUniversitaria

class GeorefClient:
    """Cliente base para la API Georef."""
    
    # Mapeo de endpoints a clases modelo
    ENDPOINT_MODELS = {
        'provincias': Provincia,
        'departamentos': Departamento,
        'municipios': Municipio,
        'localidades': Localidad,
        'localidades_censales': LocalidadCensal,
        'calles': Calle,
        'asentamientos': Asentamiento,
        'ubicacion': Ubicacion,
        'gobiernos_locales': GobiernoLocal,
        'aglomerados': Aglomerado,
        'fracciones_censales': FraccionCensal,
        'radios_censales': RadioCensal,
        'direcciones': DireccionNormalizada,
        'establecimientos_educativos': EstablecimientoEducativo,
        'instituciones_universitarias': InstitucionUniversitaria,
    }

    # Mapeo de claves internas a segmentos URL (para endpoints que requieren guiones)
    ENDPOINT_URL_SEGMENTS = {
        'gobiernos_locales': 'gobiernos-locales',
        'localidades_censales': 'localidades-censales',
        'fracciones_censales': 'fracciones-censales',
        'radios_censales': 'radios-censales',
        'establecimientos_educativos': 'establecimientos-educativos',
        'instituciones_universitarias': 'instituciones-universitarias',
    }
    
    def __init__(self, jwt_token: str = None):
        """
        Args:
            jwt_token: Token JWT opcional para organismos de la APN que requieran
                       mayor cuota de uso. Ver https://datosgobar.github.io/georef-ar-api/jwt-token/
        """
        self.base_url = 'https://apis.datos.gob.ar/georef/api/v2.0/'
        self._headers = {'Authorization': f'Bearer {jwt_token}'} if jwt_token else {}

    def _clean_params(self, params):
        """Serializa los parámetros usando dump_params(), que excluye None y convierte enteros a strings."""
        if params is None:
            return {}
        return params.dump_params()

    def _get(self, endpoint, params=None):
        url_segment = self.ENDPOINT_URL_SEGMENTS.get(endpoint, endpoint)
        url = f"{self.base_url}{url_segment}"
        response = requests.get(url, params=self._clean_params(params), headers=self._headers)
        if response.status_code != 200:
            raise GeorefClientException(f'Error {response.status_code}: {response.text}')
        return response.json()

    def _validate_params(self, params, model):
        if params is None:
            return None
        if isinstance(params, dict):
            params = model.Params(**params)
        elif not isinstance(params, model.Params):
            raise ValueError(f"Los parámetros deben ser una instancia de {model.__name__}.Params o un diccionario.")
        return params

    def _get_items(self, endpoint, params=None):
        if endpoint not in self.ENDPOINT_MODELS:
            raise ValueError(f"Endpoint '{endpoint}' no soportado. Endpoints disponibles: {list(self.ENDPOINT_MODELS.keys())}")
        
        model = self.ENDPOINT_MODELS[endpoint]
        params = self._validate_params(params, model)
        response = self._get(endpoint, params=params)

        # El endpoint 'ubicacion' devuelve un objeto único, no una lista
        if endpoint == 'ubicacion':
            obj = response.get('ubicacion')
            if obj is None:
                return []
            return [model(**obj)]

        items = response.get(endpoint, [])
        return [model(**item) for item in items]

    def get_provincias(self, params = None):
        return self._get_items('provincias', params)
    
    def get_departamentos(self, params = None):
        return self._get_items('departamentos', params)
    
    def get_municipios(self, params = None):
        return self._get_items('municipios', params)
    
    def get_localidades(self, params = None):
        return self._get_items('localidades', params)
    
    def get_localidades_censales(self, params = None):  
        return self._get_items('localidades_censales', params)

    def get_calles(self, params = None):
        return self._get_items('calles', params)
    
    def get_asentamientos(self, params = None):
        return self._get_items('asentamientos', params)
    
    def get_gobiernos_locales(self, params = None):
        return self._get_items('gobiernos_locales', params)
    
    def get_aglomerados(self, params = None):
        return self._get_items('aglomerados', params)
    
    def get_fracciones_censales(self, params = None):
        return self._get_items('fracciones_censales', params)
    
    def get_radios_censales(self, params = None):
        return self._get_items('radios_censales', params)
    
    def get_direcciones(self, params = None):
        return self._get_items('direcciones', params)
    
    def get_establecimientos_educativos(self, params = None):
        return self._get_items('establecimientos_educativos', params)
    
    def get_instituciones_universitarias(self, params = None):
        return self._get_items('instituciones_universitarias', params)
    
    def get_georef_inversa(self, params = None):
        return self._get_items('ubicacion', params)
    
    # Límites de la API para POST en lote (ver docs de georef-ar-api).
    BATCH_MAX_QUERIES = 1000
    BATCH_MAX_SUM_OF_MAX = 5000

    def _chunk_queries(self, queries):
        """
        Divide la lista de queries en lotes que respetan los límites de la API:
        hasta BATCH_MAX_QUERIES consultas por lote y suma del parámetro 'max' no
        mayor a BATCH_MAX_SUM_OF_MAX. Imprescindible para volúmenes grandes: un
        único POST con miles de consultas es rechazado por la API.
        """
        batches = []
        current = []
        count = 0
        sum_max = 0
        for query in queries:
            q_max = 0
            if isinstance(query, dict) and query.get('max') is not None:
                try:
                    q_max = int(query['max'])
                except (TypeError, ValueError):
                    q_max = 0
                if q_max < 0:
                    q_max = 0
            exceeds_count = count + 1 > self.BATCH_MAX_QUERIES
            exceeds_sum = q_max > 0 and sum_max + q_max > self.BATCH_MAX_SUM_OF_MAX
            if current and (exceeds_count or exceeds_sum):
                batches.append(current)
                current, count, sum_max = [], 0, 0
            current.append(query)
            count += 1
            sum_max += q_max
        if current:
            batches.append(current)
        return batches

    def _post_bulk(self, endpoint, queries, model_class, on_progress=None):
        """
        Método genérico para búsquedas en lote (POST). Trocea automáticamente en
        lotes que respetan los límites de la API y concatena los resultados en el
        orden original.

        Args:
            endpoint: Nombre del endpoint (ej: 'provincias')
            queries: Lista de diccionarios con parámetros de búsqueda
            model_class: Clase del modelo asociado (ej: Provincia)
            on_progress: callback opcional on_progress(hechas, total), una vez por lote

        Returns:
            Lista de resultados (una lista de modelos por cada query enviada)
        """
        if endpoint not in self.ENDPOINT_MODELS:
            raise ValueError(f"Endpoint '{endpoint}' no soportado.")

        # Validar cada query
        validated_queries = []
        for query in queries:
            params = self._validate_params(query, model_class)
            validated_queries.append(params.model_dump(exclude_none=True) if params else {})

        url_segment = self.ENDPOINT_URL_SEGMENTS.get(endpoint, endpoint)
        url = f"{self.base_url}{url_segment}"

        all_results = []
        total = len(validated_queries)
        done = 0
        for batch in self._chunk_queries(validated_queries):
            response = requests.post(url, json={endpoint: batch}, headers=self._headers)
            if response.status_code != 200:
                raise GeorefClientException(f'Error {response.status_code}: {response.text}')
            for result in response.json().get('resultados', []):
                items = result.get(endpoint, [])
                all_results.append([model_class(**item) for item in items])
            done += len(batch)
            if on_progress is not None:
                on_progress(done, total)

        return all_results
    
    # Métodos POST para búsquedas en lote
    def post_provincias(self, queries):
        """POST búsqueda en lote de provincias."""
        return self._post_bulk('provincias', queries, Provincia)
    
    def post_departamentos(self, queries):
        """POST búsqueda en lote de departamentos."""
        return self._post_bulk('departamentos', queries, Departamento)
    
    def post_municipios(self, queries):
        """POST búsqueda en lote de municipios."""
        return self._post_bulk('municipios', queries, Municipio)
    
    def post_localidades(self, queries):
        """POST búsqueda en lote de localidades."""
        return self._post_bulk('localidades', queries, Localidad)
    
    def post_localidades_censales(self, queries):
        """POST búsqueda en lote de localidades censales."""
        return self._post_bulk('localidades_censales', queries, LocalidadCensal)
    
    def post_calles(self, queries):
        """POST búsqueda en lote de calles."""
        return self._post_bulk('calles', queries, Calle)
    
    def post_asentamientos(self, queries):
        """POST búsqueda en lote de asentamientos."""
        return self._post_bulk('asentamientos', queries, Asentamiento)
    
    def post_gobiernos_locales(self, queries):
        """POST búsqueda en lote de gobiernos locales."""
        return self._post_bulk('gobiernos_locales', queries, GobiernoLocal)
    
    def post_aglomerados(self, queries):
        """POST búsqueda en lote de aglomerados."""
        return self._post_bulk('aglomerados', queries, Aglomerado)
    
    def post_fracciones_censales(self, queries):
        """POST búsqueda en lote de fracciones censales."""
        return self._post_bulk('fracciones_censales', queries, FraccionCensal)
    
    def post_radios_censales(self, queries):
        """POST búsqueda en lote de radios censales."""
        return self._post_bulk('radios_censales', queries, RadioCensal)
    
    def post_direcciones(self, queries):
        """POST normalización en lote de direcciones."""
        return self._post_bulk('direcciones', queries, DireccionNormalizada)
    
    def post_establecimientos_educativos(self, queries):
        """POST búsqueda en lote de establecimientos educativos."""
        return self._post_bulk('establecimientos_educativos', queries, EstablecimientoEducativo)
    
    def post_instituciones_universitarias(self, queries):
        """POST búsqueda en lote de instituciones universitarias."""
        return self._post_bulk('instituciones_universitarias', queries, InstitucionUniversitaria)
    
    def post_ubicacion(self, queries, on_progress=None):
        """POST georreferencia inversa en lote para puntos (troceado por lotes)."""
        # Este endpoint es especial - usa lat/lon en lugar de params genéricos.
        validated_queries = []
        for query in queries:
            if not isinstance(query, dict) or 'lat' not in query or 'lon' not in query:
                raise ValueError("Cada query debe tener 'lat' y 'lon'")
            validated_queries.append(query)

        url = f"{self.base_url}ubicacion"
        all_results = []
        total = len(validated_queries)
        done = 0
        for batch in self._chunk_queries(validated_queries):
            response = requests.post(url, json={'ubicaciones': batch}, headers=self._headers)
            if response.status_code != 200:
                raise GeorefClientException(f'Error {response.status_code}: {response.text}')
            for result in response.json().get('resultados', []):
                all_results.append(Ubicacion(**result.get('ubicacion', {})))
            done += len(batch)
            if on_progress is not None:
                on_progress(done, total)

        return all_results
    
class GeorefClientException(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return f'GeorefClientException: {self.message}'
