"""
Configuración y fixtures para tests de pygeorefar.
"""

import pytest
from unittest.mock import Mock, patch
from src.georef_client import GeorefClient
from src.models.provincia import Provincia
from src.models.departamento import Departamento


@pytest.fixture
def client():
    """Fixture: instancia de GeorefClient."""
    return GeorefClient()


@pytest.fixture
def mock_provincia_response():
    """Fixture: respuesta mock para provincias."""
    return {
        'provincias': [
            {
                'id': '02',
                'nombre': 'Buenos Aires',
                'iso_id': 'AR-B',
                'iso_nombre': 'Buenos Aires',
                'categoria': 'Provincia',
                'centroide': {
                    'lat': -36.5,
                    'lon': -60.0
                }
            },
            {
                'id': '82',
                'nombre': 'Santa Fe',
                'iso_id': 'AR-S',
                'iso_nombre': 'Santa Fe',
                'categoria': 'Provincia',
                'centroide': {
                    'lat': -30.7,
                    'lon': -60.6
                }
            }
        ],
        'cantidad': 2,
        'total': 24,
        'inicio': 0,
        'parametros': {}
    }


@pytest.fixture
def mock_departamento_response():
    """Fixture: respuesta mock para departamentos."""
    return {
        'departamentos': [
            {
                'id': '02007',
                'nombre': 'Almirante Brown',
                'nombre_completo': 'Departamento Almirante Brown',
                'provincia': {
                    'id': '02',
                    'nombre': 'Buenos Aires'
                },
                'centroide': {
                    'lat': -34.8,
                    'lon': -58.4
                },
                'categoria': 'Departamento'
            }
        ],
        'cantidad': 1,
        'total': 125,
        'inicio': 0,
        'parametros': {}
    }


@pytest.fixture
def mock_bulk_response():
    """Fixture: respuesta mock para búsquedas en lote."""
    return {
        'resultados': [
            {
                'provincias': [
                    {
                        'id': '02',
                        'nombre': 'Buenos Aires',
                        'iso_id': 'AR-B',
                        'iso_nombre': 'Buenos Aires',
                        'categoria': 'Provincia',
                        'centroide': {'lat': -36.5, 'lon': -60.0}
                    }
                ],
                'cantidad': 1,
                'total': 1,
                'inicio': 0,
                'parametros': {'nombre': 'Buenos Aires'}
            },
            {
                'provincias': [
                    {
                        'id': '82',
                        'nombre': 'Santa Fe',
                        'iso_id': 'AR-S',
                        'iso_nombre': 'Santa Fe',
                        'categoria': 'Provincia',
                        'centroide': {'lat': -30.7, 'lon': -60.6}
                    }
                ],
                'cantidad': 1,
                'total': 1,
                'inicio': 0,
                'parametros': {'nombre': 'Santa Fe'}
            }
        ]
    }


@pytest.fixture
def mock_requests_get(mock_provincia_response):
    """Fixture: mock de requests.get."""
    with patch('src.georef_client.requests.get') as mock_get:
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = mock_provincia_response
        mock_get.return_value = mock_response
        yield mock_get


@pytest.fixture
def mock_requests_post(mock_bulk_response):
    """Fixture: mock de requests.post."""
    with patch('src.georef_client.requests.post') as mock_post:
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = mock_bulk_response
        mock_post.return_value = mock_response
        yield mock_post
