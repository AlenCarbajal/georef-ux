"""Tests de integración para pygeorefar"""
