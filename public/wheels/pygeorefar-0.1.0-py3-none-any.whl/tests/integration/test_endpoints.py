"""
Tests de integración para endpoints GET (contra API real).

Estos tests requieren conexión a la API real y pueden ser lentos.
Ejecutar con: pytest -m integration
"""

import pytest
from src.georef_client import GeorefClient


@pytest.mark.integration
class TestProvinciasEndpoint:
    """Tests de integración para endpoint /provincias."""
    
    @pytest.fixture(scope="class")
    def client(self):
        return GeorefClient()
    
    def test_get_all_provincias(self, client):
        """Test obtener todas las provincias."""
        result = client.get_provincias({'max': 5})
        assert isinstance(result, list)
        assert len(result) <= 5
        if result:
            assert hasattr(result[0], 'id')
            assert hasattr(result[0], 'nombre')
    
    def test_get_provincias_by_name(self, client):
        """Test buscar provincia por nombre."""
        result = client.get_provincias({'nombre': 'Buenos Aires'})
        assert isinstance(result, list)
        if result:
            assert result[0].nombre.lower().find('buenos aires') != -1


@pytest.mark.integration
class TestDepartamentosEndpoint:
    """Tests de integración para endpoint /departamentos."""
    
    @pytest.fixture(scope="class")
    def client(self):
        return GeorefClient()
    
    def test_get_departamentos(self, client):
        """Test obtener departamentos."""
        result = client.get_departamentos({'max': 5})
        assert isinstance(result, list)
        assert len(result) <= 5


@pytest.mark.integration
class TestCallesEndpoint:
    """Tests de integración para endpoint /calles."""
    
    @pytest.fixture(scope="class")
    def client(self):
        return GeorefClient()
    
    def test_get_calles(self, client):
        """Test obtener calles."""
        result = client.get_calles({
            'provincia': 'Santa Fe',
            'departamento': 'Rosario',
            'max': 5
        })
        assert isinstance(result, list)


@pytest.mark.integration
class TestAsentamientosEndpoint:
    """Tests de integración para endpoint /asentamientos."""
    
    @pytest.fixture(scope="class")
    def client(self):
        return GeorefClient()
    
    def test_get_asentamientos(self, client):
        """Test obtener asentamientos."""
        result = client.get_asentamientos({'max': 5})
        assert isinstance(result, list)


@pytest.mark.integration
class TestHyphenEndpoints:
    """Tests de integración para endpoints que requieren guiones en la URL (Bug 3)."""

    @pytest.fixture(scope="class")
    def client(self):
        return GeorefClient()

    def test_get_gobiernos_locales(self, client):
        """Test que get_gobiernos_locales no retorna 404 (URL con guiones)."""
        result = client.get_gobiernos_locales({'max': 3})
        assert isinstance(result, list)

    def test_get_localidades_censales(self, client):
        """Test que get_localidades_censales no retorna 404."""
        result = client.get_localidades_censales({'max': 3})
        assert isinstance(result, list)

    def test_get_fracciones_censales(self, client):
        """Test que get_fracciones_censales no retorna 404."""
        result = client.get_fracciones_censales({'max': 3})
        assert isinstance(result, list)

    def test_get_radios_censales(self, client):
        """Test que get_radios_censales no retorna 404."""
        result = client.get_radios_censales({'max': 3})
        assert isinstance(result, list)

    def test_get_establecimientos_educativos(self, client):
        """Test que get_establecimientos_educativos no retorna 404."""
        result = client.get_establecimientos_educativos({'max': 3})
        assert isinstance(result, list)

    def test_get_instituciones_universitarias(self, client):
        """Test que get_instituciones_universitarias no retorna 404."""
        result = client.get_instituciones_universitarias({'max': 3})
        assert isinstance(result, list)


@pytest.mark.integration
class TestGeoreferenciaInversa:
    """Tests de integración para georreferencia inversa (Bug 2)."""

    @pytest.fixture(scope="class")
    def client(self):
        return GeorefClient()

    def test_get_georef_inversa_returns_ubicacion(self, client):
        """Test que get_georef_inversa retorna una Ubicacion válida."""
        result = client.get_georef_inversa({'lat': -34.60, 'lon': -58.43})
        assert isinstance(result, list)
        assert len(result) == 1
        assert result[0].provincia is not None

    def test_get_georef_inversa_rosario(self, client):
        """Test georreferencia inversa para coordenadas de Rosario."""
        result = client.get_georef_inversa({'lat': -32.88, 'lon': -60.70})
        assert isinstance(result, list)
        assert len(result) == 1
        ubicacion = result[0]
        assert ubicacion.provincia is not None
        assert 'santa fe' in ubicacion.provincia.nombre.lower()
