"""
Tests de integración para operaciones en lote (POST).

Estos tests requieren conexión a la API real.
Ejecutar con: pytest -m integration
"""

import pytest
from src.georef_client import GeorefClient


@pytest.mark.integration
class TestProvinciasBulk:
    """Tests de integración para POST /provincias."""
    
    @pytest.fixture(scope="class")
    def client(self):
        return GeorefClient()
    
    def test_post_provincias_basic(self, client):
        """Test realizar búsqueda en lote de provincias."""
        queries = [
            {'nombre': 'Buenos Aires'},
            {'nombre': 'Santa Fe'},
        ]
        result = client.post_provincias(queries)
        assert isinstance(result, list)
        assert len(result) == 2
        # Cada resultado debe ser una lista de provincias
        assert isinstance(result[0], list)


@pytest.mark.integration
class TestDepartamentosBulk:
    """Tests de integración para POST /departamentos."""
    
    @pytest.fixture(scope="class")
    def client(self):
        return GeorefClient()
    
    def test_post_departamentos_basic(self, client):
        """Test realizar búsqueda en lote de departamentos."""
        queries = [
            {'provincia': 'Buenos Aires', 'max': 2},
            {'provincia': 'Santa Fe', 'max': 2},
        ]
        result = client.post_departamentos(queries)
        assert isinstance(result, list)
        assert len(result) == 2


@pytest.mark.integration
class TestUbicacionBulk:
    """Tests de integración para POST /ubicacion."""
    
    @pytest.fixture(scope="class")
    def client(self):
        return GeorefClient()
    
    def test_post_ubicacion_basic(self, client):
        """Test georreferencia inversa en lote."""
        queries = [
            {'lat': -32.88, 'lon': -60.70},  # Rosario
            {'lat': -34.60, 'lon': -58.43},  # Buenos Aires
        ]
        result = client.post_ubicacion(queries)
        assert isinstance(result, list)
        assert len(result) == 2
