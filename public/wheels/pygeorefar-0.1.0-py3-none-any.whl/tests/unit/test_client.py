"""
Tests unitarios para GeorefClient (sin HTTP real).
"""

import pytest
from unittest.mock import patch, Mock
from src.georef_client import GeorefClient, GeorefClientException
from src.models.provincia import Provincia
from src.models.departamento import Departamento


class TestGeorefClientInit:
    """Tests para inicialización de GeorefClient."""
    
    def test_client_init(self):
        """Test que GeorefClient se inicializa correctamente."""
        client = GeorefClient()
        assert client.base_url == 'https://apis.datos.gob.ar/georef/api/v2.0/'
    
    def test_client_init_no_token(self):
        """Test que sin token los headers están vacíos."""
        client = GeorefClient()
        assert client._headers == {}

    def test_client_init_with_jwt_token(self):
        """Test que con token se configura el header Authorization."""
        client = GeorefClient(jwt_token='mi.token.jwt')
        assert client._headers == {'Authorization': 'Bearer mi.token.jwt'}

    def test_endpoint_models_registered(self):
        """Test que todos los endpoints están registrados."""
        client = GeorefClient()
        assert len(client.ENDPOINT_MODELS) == 15
        assert 'provincias' in client.ENDPOINT_MODELS
        assert 'aglomerados' in client.ENDPOINT_MODELS


class TestValidateParams:
    """Tests para validación de parámetros."""
    
    def test_validate_params_none(self):
        """Test que None es válido."""
        client = GeorefClient()
        result = client._validate_params(None, Provincia)
        assert result is None
    
    def test_validate_params_dict(self):
        """Test que dict se convierte a Params."""
        client = GeorefClient()
        result = client._validate_params({'nombre': 'Buenos Aires'}, Provincia)
        assert isinstance(result, Provincia.Params)
        assert result.model_dump()['nombre'] == 'Buenos Aires'
    
    def test_validate_params_instance(self):
        """Test que instancia de Params es aceptada."""
        client = GeorefClient()
        params = Provincia.Params(nombre='Buenos Aires')
        result = client._validate_params(params, Provincia)
        assert result == params
    
    def test_validate_params_invalid_type(self):
        """Test que tipo inválido lanza excepción."""
        client = GeorefClient()
        with pytest.raises(ValueError):
            client._validate_params("invalid", Provincia)


class TestCleanParams:
    """Tests para limpieza de parámetros."""
    
    def test_clean_params_none(self):
        """Test que None devuelve dict vacío."""
        client = GeorefClient()
        result = client._clean_params(None)
        assert result == {}
    
    def test_clean_params_removes_none_values(self):
        """Test que elimina valores None."""
        client = GeorefClient()
        params = Provincia.Params(nombre='Buenos Aires', max=None)
        result = client._clean_params(params)
        assert 'nombre' in result
        assert 'max' not in result

    def test_clean_params_converts_integers_to_strings(self):
        """Test que convierte enteros a strings (Bug 4 fix)."""
        client = GeorefClient()
        params = Provincia.Params(max=10, inicio=5)
        result = client._clean_params(params)
        assert result['max'] == '10'
        assert result['inicio'] == '5'
        assert isinstance(result['max'], str)
        assert isinstance(result['inicio'], str)

    def test_clean_params_uses_dump_params(self):
        """Test que _clean_params delega en dump_params() del modelo."""
        client = GeorefClient()
        params = Provincia.Params(nombre='Córdoba', max=3)
        result = client._clean_params(params)
        # dump_params excluye None y convierte int a str
        assert result == {'nombre': 'Córdoba', 'max': '3'}


class TestGetMethods:
    """Tests para métodos GET."""
    
    def test_get_items_invalid_endpoint(self):
        """Test que endpoint inválido lanza excepción."""
        client = GeorefClient()
        with pytest.raises(ValueError, match="no soportado"):
            client._get_items('invalid_endpoint')

    def test_get_georef_inversa_returns_single_ubicacion(self):
        """Test que get_georef_inversa parsea objeto único de la API (Bug 2 fix)."""
        client = GeorefClient()
        mock_response = {
            "ubicacion": {
                "departamento": {"id": "06", "nombre": "Buenos Aires"},
                "provincia": {"id": "06", "nombre": "Buenos Aires"},
                "municipio": None,
                "lat": -34.6,
                "lon": -58.4,
            }
        }
        with patch.object(client, '_get', return_value=mock_response):
            result = client.get_georef_inversa({'lat': -34.6, 'lon': -58.4})
        assert len(result) == 1
        assert result[0].lat == -34.6
        assert result[0].lon == -58.4

    def test_get_georef_inversa_returns_empty_when_no_ubicacion(self):
        """Test que get_georef_inversa retorna lista vacía si la respuesta no tiene 'ubicacion'."""
        client = GeorefClient()
        mock_response = {}
        with patch.object(client, '_get', return_value=mock_response):
            result = client.get_georef_inversa({'lat': -34.6, 'lon': -58.4})
        assert result == []
    
    def test_get_provincias_exists(self):
        """Test que método get_provincias existe."""
        client = GeorefClient()
        assert hasattr(client, 'get_provincias')
    
    def test_all_get_methods_exist(self):
        """Test que todos los métodos GET existen."""
        client = GeorefClient()
        expected_methods = [
            'get_provincias', 'get_departamentos', 'get_municipios',
            'get_localidades', 'get_localidades_censales', 'get_calles',
            'get_asentamientos', 'get_gobiernos_locales', 'get_aglomerados',
            'get_fracciones_censales', 'get_radios_censales', 'get_direcciones',
            'get_establecimientos_educativos', 'get_instituciones_universitarias',
            'get_georef_inversa'
        ]
        for method in expected_methods:
            assert hasattr(client, method), f"Falta método {method}"


class TestEndpointURLSegments:
    """Tests para el mapeo de endpoints a segmentos URL con guiones (Bug 3)."""

    EXPECTED_SEGMENTS = {
        'gobiernos_locales': 'gobiernos-locales',
        'localidades_censales': 'localidades-censales',
        'fracciones_censales': 'fracciones-censales',
        'radios_censales': 'radios-censales',
        'establecimientos_educativos': 'establecimientos-educativos',
        'instituciones_universitarias': 'instituciones-universitarias',
    }

    def test_endpoint_url_segments_contains_all_six_mappings(self):
        """Test que ENDPOINT_URL_SEGMENTS contiene los 6 mapeos con guiones."""
        client = GeorefClient()
        for key, expected_segment in self.EXPECTED_SEGMENTS.items():
            assert key in client.ENDPOINT_URL_SEGMENTS, f"Falta clave '{key}' en ENDPOINT_URL_SEGMENTS"
            assert client.ENDPOINT_URL_SEGMENTS[key] == expected_segment, (
                f"Segmento incorrecto para '{key}': "
                f"esperado '{expected_segment}', obtenido '{client.ENDPOINT_URL_SEGMENTS[key]}'"
            )

    def test_endpoint_url_segments_uses_hyphens_not_underscores(self):
        """Test que los segmentos URL usan guiones, no guiones bajos."""
        client = GeorefClient()
        for key, segment in client.ENDPOINT_URL_SEGMENTS.items():
            assert '_' not in segment, (
                f"El segmento URL para '{key}' contiene guión bajo: '{segment}'"
            )
            assert '-' in segment, (
                f"El segmento URL para '{key}' no contiene guión: '{segment}'"
            )

    @pytest.mark.parametrize("endpoint,expected_segment", [
        ('gobiernos_locales', 'gobiernos-locales'),
        ('localidades_censales', 'localidades-censales'),
        ('fracciones_censales', 'fracciones-censales'),
        ('radios_censales', 'radios-censales'),
        ('establecimientos_educativos', 'establecimientos-educativos'),
        ('instituciones_universitarias', 'instituciones-universitarias'),
    ])
    def test_get_uses_hyphen_url_segment(self, endpoint, expected_segment):
        """Test que _get() construye la URL con el segmento correcto (con guiones)."""
        client = GeorefClient()
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {endpoint: []}
            mock_get.return_value = mock_response

            client._get(endpoint)

            called_url = mock_get.call_args[0][0]
            assert expected_segment in called_url, (
                f"URL construida para '{endpoint}' no contiene '{expected_segment}': {called_url}"
            )
            assert endpoint.replace('-', '_') not in called_url or expected_segment in called_url

    def test_endpoints_without_hyphens_use_key_directly(self):
        """Test que endpoints sin guiones (provincias, departamentos, etc.) usan la clave directamente."""
        client = GeorefClient()
        plain_endpoints = ['provincias', 'departamentos', 'municipios', 'localidades', 'calles', 'asentamientos']
        for endpoint in plain_endpoints:
            assert endpoint not in client.ENDPOINT_URL_SEGMENTS, (
                f"El endpoint '{endpoint}' no debería estar en ENDPOINT_URL_SEGMENTS"
            )


class TestEndpointURLSegments:
    """Tests para el mapeo de endpoints a segmentos URL con guiones (Bug 3)."""

    EXPECTED_SEGMENTS = {
        'gobiernos_locales': 'gobiernos-locales',
        'localidades_censales': 'localidades-censales',
        'fracciones_censales': 'fracciones-censales',
        'radios_censales': 'radios-censales',
        'establecimientos_educativos': 'establecimientos-educativos',
        'instituciones_universitarias': 'instituciones-universitarias',
    }

    def test_endpoint_url_segments_contains_all_six_mappings(self):
        """Test que ENDPOINT_URL_SEGMENTS contiene los 6 mapeos con guiones."""
        client = GeorefClient()
        for key, expected_segment in self.EXPECTED_SEGMENTS.items():
            assert key in client.ENDPOINT_URL_SEGMENTS
            assert client.ENDPOINT_URL_SEGMENTS[key] == expected_segment

    def test_endpoint_url_segments_uses_hyphens_not_underscores(self):
        """Test que los segmentos URL usan guiones, no guiones bajos."""
        client = GeorefClient()
        for key, segment in client.ENDPOINT_URL_SEGMENTS.items():
            assert '_' not in segment
            assert '-' in segment

    @pytest.mark.parametrize("endpoint,expected_segment", [
        ('gobiernos_locales', 'gobiernos-locales'),
        ('localidades_censales', 'localidades-censales'),
        ('fracciones_censales', 'fracciones-censales'),
        ('radios_censales', 'radios-censales'),
        ('establecimientos_educativos', 'establecimientos-educativos'),
        ('instituciones_universitarias', 'instituciones-universitarias'),
    ])
    def test_get_uses_hyphen_url_segment(self, endpoint, expected_segment):
        """Test que _get() construye la URL con el segmento correcto (con guiones)."""
        client = GeorefClient()
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {endpoint: []}
            mock_get.return_value = mock_response
            client._get(endpoint)
            called_url = mock_get.call_args[0][0]
            assert expected_segment in called_url

    def test_plain_endpoints_not_in_url_segments(self):
        """Test que endpoints simples no están en ENDPOINT_URL_SEGMENTS."""
        client = GeorefClient()
        for endpoint in ['provincias', 'departamentos', 'municipios', 'localidades', 'calles']:
            assert endpoint not in client.ENDPOINT_URL_SEGMENTS


class TestJWTToken:
    """Tests para autenticación JWT opcional."""

    def test_get_sends_authorization_header_when_token_set(self):
        """Test que _get() envía el header Authorization cuando hay token."""
        client = GeorefClient(jwt_token='mi.token.jwt')
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {'provincias': []}
            mock_get.return_value = mock_response

            client._get('provincias')

            _, kwargs = mock_get.call_args
            assert kwargs.get('headers') == {'Authorization': 'Bearer mi.token.jwt'}

    def test_get_sends_no_authorization_header_without_token(self):
        """Test que _get() no envía Authorization cuando no hay token."""
        client = GeorefClient()
        with patch('requests.get') as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {'provincias': []}
            mock_get.return_value = mock_response

            client._get('provincias')

            _, kwargs = mock_get.call_args
            assert kwargs.get('headers') == {}


class TestPostMethods:
    """Tests para métodos POST."""
    
    def test_post_provincias_exists(self):
        """Test que método post_provincias existe."""
        client = GeorefClient()
        assert hasattr(client, 'post_provincias')
    
    def test_all_post_methods_exist(self):
        """Test que todos los métodos POST existen."""
        client = GeorefClient()
        expected_methods = [
            'post_provincias', 'post_departamentos', 'post_municipios',
            'post_localidades', 'post_localidades_censales', 'post_calles',
            'post_asentamientos', 'post_gobiernos_locales', 'post_aglomerados',
            'post_fracciones_censales', 'post_radios_censales', 'post_direcciones',
            'post_establecimientos_educativos', 'post_instituciones_universitarias',
            'post_ubicacion'
        ]
        for method in expected_methods:
            assert hasattr(client, method), f"Falta método {method}"


class TestExceptions:
    """Tests para manejo de excepciones."""
    
    def test_exception_message(self):
        """Test que GeorefClientException formatea bien el mensaje."""
        exc = GeorefClientException("Error 404")
        assert "GeorefClientException" in str(exc)
        assert "Error 404" in str(exc)
