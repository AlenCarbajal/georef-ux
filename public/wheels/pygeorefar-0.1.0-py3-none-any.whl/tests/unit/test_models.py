"""
Tests unitarios para modelos Pydantic de pygeorefar.
"""

import pytest
from pydantic import ValidationError
from src.models.provincia import Provincia
from src.models.departamento import Departamento
from src.models.municipio import Municipio
from src.models.localidad import Localidad
from src.models.calle import Calle
from src.models.asentamiento import Asentamiento
from src.models.ubicacion import Ubicacion
from src.models.fraccion_censal import FraccionCensal
from src.models.radio_censal import RadioCensal
from src.models.establecimiento_educativo import EstablecimientoEducativo
from src.models.institucion_universitaria import InstitucionUniversitaria


class TestProvinciaModel:
    """Tests para modelo Provincia."""
    
    def test_provincia_required_fields(self):
        """Test que Provincia requiere campos obligatorios."""
        with pytest.raises(ValidationError):
            Provincia()
    
    def test_provincia_minimal(self):
        """Test crear Provincia con campos mínimos."""
        prov = Provincia(id='02', nombre='Buenos Aires')
        assert prov.id == '02'
        assert prov.nombre == 'Buenos Aires'
    
    def test_provincia_full(self):
        """Test crear Provincia con todos los campos."""
        prov = Provincia(
            id='02',
            nombre='Buenos Aires',
            iso_id='AR-B',
            iso_nombre='Buenos Aires',
            categoria='Provincia',
            centroide=None
        )
        assert prov.iso_id == 'AR-B'
        assert prov.iso_nombre == 'Buenos Aires'
    
    def test_provincia_params(self):
        """Test parámetros de búsqueda para Provincia."""
        params = Provincia.Params()
        assert params is not None


class TestDepartamentoModel:
    """Tests para modelo Departamento."""
    
    def test_departamento_minimal(self):
        """Test crear Departamento con campos mínimos."""
        prov = Provincia(id='02', nombre='Buenos Aires')
        dept = Departamento(id='02007', nombre='Almirante Brown', provincia=prov)
        assert dept.id == '02007'
        assert dept.nombre == 'Almirante Brown'
        assert dept.provincia.nombre == 'Buenos Aires'
    
    def test_departamento_params(self):
        """Test parámetros de búsqueda para Departamento."""
        params = Departamento.Params(provincia='Buenos Aires')
        assert params.model_dump()['provincia'] == 'Buenos Aires'


class TestCalleModel:
    """Tests para modelo Calle."""
    
    def test_calle_minimal(self):
        """Test crear Calle con campos mínimos."""
        calle = Calle(id='8208416001280', nombre='URQUIZA')
        assert calle.id == '8208416001280'
        assert calle.nombre == 'URQUIZA'
    
    def test_calle_params(self):
        """Test parámetros de búsqueda para Calle."""
        params = Calle.Params(nombre='URQUIZA')
        assert params.nombre == 'URQUIZA'


class TestAsentamientoModel:
    """Tests para modelo Asentamiento."""
    
    def test_asentamiento_minimal(self):
        """Test crear Asentamiento con campos mínimos."""
        asent = Asentamiento(id='82084000012', nombre='El Prado')
        assert asent.id == '82084000012'
        assert asent.nombre == 'El Prado'


class TestModelParamsValidation:
    """Tests para validación de parámetros de modelos."""
    
    def test_provincia_params_none(self):
        """Test que Params acepta None."""
        params = Provincia.Params()
        assert params is not None
    
    def test_provincia_params_optional_fields(self):
        """Test que campos son opcionales."""
        params = Provincia.Params(
            id='02',
            nombre='Buenos Aires',
            max=10
        )
        dump = params.model_dump()
        assert dump['id'] == '02'
        assert dump['nombre'] == 'Buenos Aires'
        assert dump['max'] == 10
    
    def test_params_invalid_max(self):
        """Test que max tiene límites - puede ser None pero no > 5000."""
        # En la spec, max debe estar entre 1 y 5000
        # Si no especificamos validator, Pydantic solo valida el tipo
        # Creamos sin error (porque es opcional)
        params = Provincia.Params(max=10)
        assert params.model_dump()['max'] == 10
    
    def test_params_invalid_max_zero(self):
        """Test que max cero es aceptado (opcional)."""
        # max=0 es técnicamente válido en Pydantic, pero la API lo rechazaría
        params = Provincia.Params(max=0)
        assert params.model_dump()['max'] == 0


class TestUbicacionModel:
    """Tests para modelo Ubicacion (Bug 1: hereda de BaseModel con campos opcionales)."""

    def test_ubicacion_without_id_nombre(self):
        """Test que Ubicacion puede instanciarse sin id ni nombre (Bug 1 fix)."""
        # No debe lanzar ValidationError
        ubicacion = Ubicacion(lat=-34.6, lon=-58.4)
        assert ubicacion.lat == -34.6
        assert ubicacion.lon == -58.4

    def test_ubicacion_all_optional(self):
        """Test que Ubicacion puede instanciarse sin ningún campo."""
        # Todos los campos son opcionales
        ubicacion = Ubicacion()
        assert ubicacion is not None

    def test_ubicacion_with_lat_lon(self):
        """Test que lat y lon se asignan correctamente."""
        ubicacion = Ubicacion(lat=-34.603722, lon=-58.381592)
        assert ubicacion.lat == -34.603722
        assert ubicacion.lon == -58.381592
        assert ubicacion.departamento is None
        assert ubicacion.provincia is None
        assert ubicacion.municipio is None


class TestFraccionCensalModel:
    """Tests para modelo FraccionCensal (Bug 9: nombre es Optional)."""

    def test_fraccion_censal_without_nombre(self):
        """Test que FraccionCensal puede instanciarse sin nombre (Bug 9 fix)."""
        # No debe lanzar ValidationError
        fraccion = FraccionCensal(id='02001')
        assert fraccion.id == '02001'

    def test_fraccion_censal_nombre_defaults_to_none(self):
        """Test que nombre es None cuando no se pasa."""
        fraccion = FraccionCensal(id='02001')
        assert fraccion.nombre is None

    def test_fraccion_censal_with_nombre(self):
        """Test que FraccionCensal funciona correctamente cuando se pasa nombre."""
        fraccion = FraccionCensal(id='02001', nombre='Fracción 01')
        assert fraccion.id == '02001'
        assert fraccion.nombre == 'Fracción 01'


class TestRadioCensalModel:
    """Tests para modelo RadioCensal (Bug 10: nombre es Optional)."""

    def test_radio_censal_without_nombre(self):
        """Test que RadioCensal puede instanciarse sin nombre (Bug 10 fix)."""
        # No debe lanzar ValidationError
        radio = RadioCensal(id='02001')
        assert radio.id == '02001'

    def test_radio_censal_nombre_defaults_to_none(self):
        """Test que nombre es None cuando no se pasa."""
        radio = RadioCensal(id='02001')
        assert radio.nombre is None

    def test_radio_censal_with_nombre(self):
        """Test que RadioCensal funciona correctamente cuando se pasa nombre."""
        radio = RadioCensal(id='02001', nombre='Radio 01')
        assert radio.id == '02001'
        assert radio.nombre == 'Radio 01'


class TestEstablecimientoEducativoParams:
    """Tests para Params de EstablecimientoEducativo (Bug 5: hereda de BaseParams)."""

    def test_dump_params_available(self):
        """Test que dump_params() está disponible vía herencia de BaseParams."""
        params = EstablecimientoEducativo.Params(max=5)
        result = params.dump_params()
        assert result['max'] == '5'
        assert isinstance(result['max'], str)

    def test_integers_converted_to_strings(self):
        """Test que enteros se convierten a strings en dump_params."""
        params = EstablecimientoEducativo.Params(max=10, inicio=20)
        result = params.dump_params()
        assert result['max'] == '10'
        assert result['inicio'] == '20'

    def test_specific_fields_available(self):
        """Test que campos específicos del modelo están disponibles."""
        params = EstablecimientoEducativo.Params(
            provincia='Buenos Aires',
            departamento='Rosario',
            gestion='Estatal'
        )
        assert params.provincia == 'Buenos Aires'
        assert params.gestion == 'Estatal'

    def test_none_excluded_from_dump(self):
        """Test que campos None no aparecen en dump_params."""
        params = EstablecimientoEducativo.Params(nombre='Escuela')
        result = params.dump_params()
        assert 'nombre' in result
        assert 'max' not in result


class TestInstitucionUniversitariaParams:
    """Tests para Params de InstitucionUniversitaria (Bug 5: hereda de BaseParams)."""

    def test_dump_params_available(self):
        """Test que dump_params() está disponible vía herencia de BaseParams."""
        params = InstitucionUniversitaria.Params(max=3)
        result = params.dump_params()
        assert result['max'] == '3'
        assert isinstance(result['max'], str)

    def test_specific_fields_available(self):
        """Test que campos específicos del modelo están disponibles."""
        params = InstitucionUniversitaria.Params(
            universidad='UBA',
            gestion='Estatal'
        )
        assert params.universidad == 'UBA'
        assert params.gestion == 'Estatal'


class TestValidateCampos:
    """Tests para validate_campos en BaseParams (Bug 6: usa cls.__mro__ en lugar de globals())."""

    def test_validate_campos_from_external_context(self):
        """Test que validate_campos no lanza KeyError desde contexto externo."""
        # Antes del fix, esto lanzaba KeyError porque globals() no tenía 'Provincia'
        params = Provincia.Params(campos='id,nombre')
        assert params.campos == ['id', 'nombre']

    def test_validate_campos_establecimiento(self):
        """Test que validate_campos funciona en subclases con BaseParams."""
        params = EstablecimientoEducativo.Params(campos='id,nombre')
        assert params.campos == ['id', 'nombre']

    def test_validate_campos_invalid_raises(self):
        """Test que campos inválidos siguen lanzando ValueError."""
        with pytest.raises(Exception):
            Provincia.Params(campos='campo_inexistente')

    def test_validate_campos_none_accepted(self):
        """Test que campos=None es aceptado sin error."""
        params = Provincia.Params(campos=None)
        assert params.campos is None
